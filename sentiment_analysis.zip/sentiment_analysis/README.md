# sentiment_analysis
 This app will take a sentence as input and read the sentiment of the sentence. Whether the sentiment is positive or negative.  It also saves the Sentence and the sentiment on a cloud MongoDB.
